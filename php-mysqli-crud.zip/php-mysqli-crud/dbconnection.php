<?php
$con=mysqli_connect("db", "php_docker", "password", "php_docker");
?>